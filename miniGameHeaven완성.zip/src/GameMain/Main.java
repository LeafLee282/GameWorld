package GameMain;

import GameSQL.*;
import Games.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //입력(Scanner)을 위한 객체
        Scanner sc = new Scanner(System.in);

        GameUser user = new GameUser();
        GameSQL sql = new GameSQL();

        WheelGame wheel = new WheelGame();
        UpDownGame upDown = new UpDownGame();
        MemoryGame memory = new MemoryGame();
        HangManGame hangMan = new HangManGame();
        RSPGame rspGame = new RSPGame();
        BlackJackGame blackJack = new BlackJackGame();

        boolean run = true; //프로그램 실행을 위한 변수 : run
        int menu = 0;       //메뉴를 입력받기 위한 변수 : menu

        boolean runLogin = true; //login 프로그램 실행을 위한 변수 : run
        int menuLogin = 0;       //login 메뉴를 입력받기 위한 변수 : menu

        boolean winOrLose = false;

        sql.Connect();      //DB 연결


        System.out.println("                                    ____                                     \n" +
                " /'\\_/`\\     __              __    /\\  _`\\                                   \n" +
                "/\\      \\   /\\_\\     ___    /\\_\\   \\ \\ \\L\\_\\     __       ___ ___       __   \n" +
                "\\ \\ \\__\\ \\  \\/\\ \\  /' _ `\\  \\/\\ \\   \\ \\ \\L_L   /'__`\\   /' __` __`\\   /'__`\\ \n" +
                " \\ \\ \\_/\\ \\  \\ \\ \\ /\\ \\/\\ \\  \\ \\ \\   \\ \\ \\/, \\/\\ \\L\\.\\_ /\\ \\/\\ \\/\\ \\ /\\  __/ \n" +
                "  \\ \\_\\\\ \\_\\  \\ \\_\\\\ \\_\\ \\_\\  \\ \\_\\   \\ \\____/\\ \\__/.\\_\\\\ \\_\\ \\_\\ \\_\\\\ \\____\\\n" +
                "   \\/_/ \\/_/   \\/_/ \\/_/\\/_/   \\/_/    \\/___/  \\/__/\\/_/ \\/_/\\/_/\\/_/ \\/____/");


        System.out.println(" __  __                                                 \n" +
                "/\\ \\/\\ \\                                                \n" +
                "\\ \\ \\_\\ \\      __      __      __  __     __     ___    \n" +
                " \\ \\  _  \\   /'__`\\  /'__`\\   /\\ \\/\\ \\  /'__`\\ /' _ `\\  \n" +
                "  \\ \\ \\ \\ \\ /\\  __/ /\\ \\L\\.\\_ \\ \\ \\_/ |/\\  __/ /\\ \\/\\ \\ \n" +
                "   \\ \\_\\ \\_\\\\ \\____\\\\ \\__/.\\_\\ \\ \\___/ \\ \\____\\\\ \\_\\ \\_\\\n" +
                "    \\/_/\\/_/ \\/____/ \\/__/\\/_/  \\/__/   \\/____/ \\/_/\\/_/");






        System.out.println("미니게임천국에 오신 것을 환영합니다.");

        while (run) {
            System.out.println("==============================");
            System.out.println("[1]회원가입\t[2]로그인\t[3]종료");
            System.out.println("==============================");
            System.out.print("메뉴 선택->");
            menu = sc.nextInt();

            switch (menu) {
                case 1:
                    System.out.print("아이디를 입력->");
                    user.setgId(sc.next());

                    System.out.print("비밀번호를 입력->");
                    user.setgPw(sc.next());

                    System.out.print("닉네임을 입력->");
                    user.setgName(sc.next());

                    sql.gameJoin(user);
                    break;
                case 2:
                    System.out.print("아이디를 입력->");
                    String id = sc.next();

                    System.out.print("비밀번호를 입력->");
                    String pw = sc.next();

                    runLogin = sql.gameLogin(id, pw);

                    while (runLogin) {
                        System.out.println("===============================================");
                        System.out.println("[1]돌림판\t[2]메모리\t[3]행맨\t\t[4]가위바위보");
                        System.out.println("[5]업다운\t[6]블랙잭\t[7]내정보\t[8]로그아웃");
                        System.out.println("===============================================");
                        System.out.print("메뉴 선택->");
                        menuLogin = sc.nextInt();
                        runLogin = true;

                        if (sql.checkGrecord(id, menuLogin) && menuLogin < 7) {     //유저 전적 조회
                            sql.createGrecord(id, menuLogin);   //유저 전적 생성
                            sql.gameMoney(id, menuLogin);       //게임에 들어가는 돈 차감
                        }
                        sql.changeTier(id);                     //유저 티어 변경

                        switch (menuLogin) {
                            case 1:
                                //각 게임마다 승패
                                winOrLose = wheel.startGame();
                                break;
                            case 2:
                                winOrLose = memory.startGame();
                                break;
                            case 3:
                                winOrLose = hangMan.startGame();
                                break;
                            case 4 :
                                winOrLose = rspGame.startGame();
                                break;
                            case 5 :
                                winOrLose = upDown.startGame();
                                break;
                            case 6 :
                                winOrLose = blackJack.startGame();
                                break;
                            case 7:
                                sql.myData(id);     //자신의 정보 확인
                                sql.mySolely(id);   //게임마다 전적 확인
                                break;
                            case 8:
                                runLogin = false;
                                if(sql.getFrame().isDisplayable()) {
                                    sql.getFrame().dispose();   //로그아웃시 JFrame 닫기
                                }
                                System.out.println("로그아웃 되셨습니다.");
                                break;
                            default:
                                System.out.println("잘못 입력하셨습니다.");
                        }
                        if (winOrLose && menuLogin < 7) {            //게임 시작 및 승리, 패배 확인
                            sql.changeSolely(id, menuLogin, 1, 0);  //승리 전적 변경
                            sql.changeMoney(id, menuLogin);         //승리시 돈 획득
                            sql.setGameExp(id, menuLogin);          //승리시 경험치 획득
                        } else if (menuLogin < 7){
                            sql.changeSolely(id, menuLogin, 0, 1);  //패배 전적 변경
                        }
                    }
                    break;
                case 3:
                    sql.conClose();     //DB와 연결 끈기
                    run = false;
                    System.out.println("게임을 종료시킵니다.");
                    break;
                default:
                    System.out.println("잘못 입력하셨습니다.");
            }
        }
    }
}