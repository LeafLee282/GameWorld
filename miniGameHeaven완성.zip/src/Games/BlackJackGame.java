package Games;

import java.util.Scanner;

public class BlackJackGame {
    public boolean startGame() {
        boolean result = false;

        Scanner sc = new Scanner(System.in);
        boolean run = true;
        int[] dealer = new int[1];
        int[] user = new int[1];
        int[] temp;
        String menu = "y";
        int dealerSum = 0;
        int userSum = 0;

        System.out.println(
                "⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄⠀⠄\n" +
                "⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀⢁⠀⠂⡀\n" +
                "⠠⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀⠠⠀⢁⠀\n" +
                "⠂⠈⡀⠐⠀⡀⠂⠈⢀⠀⠂⠈⡀⠀⠂⠈⡀⠀⠂⣨⢤⠤⣆⣌⣤⣤⣦⣶⢲⢛⠋⠛⣦⠀⠂⠈⢀⠀⠂⠈⡀⠀⠂⠈⡀⠀⠂⠈⡀⢀\n" +
                "⠀⠁⡀⠄⠁⡀⠄⠁⡀⠐⠈⢀⢠⣈⣄⡥⠴⠜⢾⠃⠀⢠⡀⠀⠀⠀⠀⠁⠉⠉⠉⠋⠋⠛⠙⠚⠲⠲⠺⠴⠴⢬⡀⠁⡀⠈⡀⠁⡀⠠\n" +
                "⠄⠁⢀⠠⠀⠄⠀⠂⠀⣢⠛⠙⠉⡈⠀⠀⠀⠀⣺⠀⠀⡝⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀⣗⠀⠠⠀⠄⠂⠀⠄\n" +
                "⠄⠈⡀⠠⠀⠂⠈⡀⠁⣳⠀⠀⠉⡯⠀⠀⠀⠀⣺⠀⢼⢑⡧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀⢈⡇⠀⠂⡀⠂⢀⠁⡀\n" +
                "⠀⠂⠀⠄⠂⠈⡀⠠⠀⢺⡄⠠⡄⣹⠀⠀⠀⠀⡇⠀⣠⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⢐⠇⠈⢀⠠⠐⠀⡀⠄\n" +
                "⠈⡀⠁⡀⠂⠁⠀⠄⠂⠐⣧⠀⠉⣁⠀⠀⠀⠀⡇⠘⠿⡻⠯⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⢸⡁⠈⡀⠀⠄⠂⠀⠄\n" +
                "⠄⠀⠂⠀⠄⠁⠐⢀⠐⠀⢹⡀⢴⣿⣿⠆⠀⢨⠇⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⣸⠀⠂⢀⠐⠀⠂⠁⡀\n" +
                "⡀⠁⡈⠠⠐⠈⠀⠄⠠⠈⢘⡆⠈⠑⠂⠀⠀⢸⠅⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀     ⣞⠀⡁⠀⠄⠈⡀⠂⠀\n" +
                "⠀⠄⠠⠀⠐⠀⢁⠠⠐⠀⡀⢷⠀⠀⠀⠀⠀⣺⠁⠀⠀⠀⠀⠀⠀⢀⣴⣾⣿⣿⣿⣧⡄⠀⠀⠀⠀⠀⠀⠀⠀     ⡯⠀⠠⠐⠀⠁⡀⠄⠁\n" +
                "⠁⡀⠂⠈⡀⠁⡀⠠⠀⠂⠀⢹⡆⠀⠀⠀⠀⣟⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀⠀⠀    ⢐⡏⢀⠐⠀⡈⢀⠠⠀⠂\n" +
                "⠀⠠⠀⢁⠀⠄⠠⠐⠀⡈⠀⠂⣇⠀⠀⠀⠀⡏⠀⠀⠀⠀⠀⠀⠀⠹⢿⣿⢿⢿⣿⣿⡿⠃⠀⠀⠀⠀⠀⠀     ⢨⡇⠀⠄⠂⢀⠠⠀⠐⠈\n" +
                "⠈⢀⠐⠀⠠⠐⠀⠐⢀⠠⠈⠀⣳⠀⠀⠀⢐⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣆⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀      ⢸⠂⠀⠂⠐⠀⠠⠀⢁⠐\n" +
                "⠐⠀⠠⠈⢀⠐⠈⠀⠄⠀⠄⠁⠸⡇⠀⠀⢐⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠊⠋⠋⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⣹⠀⡁⠈⡀⢈⠀⠐⠀⠠\n" +
                "⠠⠈⢀⠐⠀⠠⠈⠀⠄⠁⡀⠂⠐⢯⠀⠀⢸⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⠀⢆⠀⠀⣞⠀⠠⠀⠄⠠⠀⢁⠈⢀\n" +
                "⢀⠐⠀⠠⠈⠀⠄⠁⡀⠂⢀⠐⠀⢹⠄⠀⣸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⠐⣿⣿⡷⠀⡧⠀⠂⠀⠂⡀⠂⢀⠐⠀\n" +
                "⠀⠠⠈⠀⠄⠁⡀⠂⢀⠐⠀⠠⠈⢈⣇⠀⣞⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⢀⡀⡁⡀⠠⡇⠂⠁⢈⠀⠠⠐⠀⠠⠈\n" +
                "⠈⠀⠄⠁⡀⠂⢀⠐⠀⠠⠈⢀⠐⠀⢻⡀⣗⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀      ⡷⡺⠁⢸⡅⠐⠈⠀⡀⠂⠠⠈⢀⠐\n" +
                "⠄⠁⡀⠂⢀⠐⠀⠠⠈⢀⠐⠀⡀⠂⢙⡆⢧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀     ⢧⠇⠀⢸⡂⠐⠈⢀⠠⠐⠀⠂⠀⠄\n" +
                "⠄⠂⢀⠐⠀⠠⠈⢀⠐⠀⡀⠂⢀⠐⠀⣗⠀⠉⠋⠋⠋⣚⣒⣶⡶⠶⠦⠦⠦⢤⢤⣤⣄⣄⣄⣀⣈⣀⣀⡽⠀⠐⠈⠀⡀⠄⠂⠁⠐⠀\n" +
                "⢀⠐⠀⠠⠈⢀⠐⠀⡀⠂⢀⠐⠀⠠⠀⡈⠓⠞⠚⠙⠉⡁⠁⠄⠀⠂⡀⠄⠐⠀⡀⢀⠀⠄⠈⡈⠁⡁⠡⠀⠄⠁⡀⢁⠀⠠⠐⠈⢀⠈\n" +
                "⠄⠠⠈⢀⠐⠀⡀⠂⢀⠐⠀⠠⠈⠀⠄⠀⠂⡀⠂⢀⠁⡀⠐⠀⢁⠠⠀⡀⠂⠁⢀⠠⠀⠐⢀⠠⠀⠄⠐⠀⠐⢀⠠⠀⠐⢀⠐⠈⢀⠀\n" +
                "⠐⠀⠐⠀⡀⠂⢀⠐⠀⠠⠈⠀⠄⠁⡀⠁⠄⠠⠐⠀⡀⠄⠂⠁⡀⠠⠀⠠⠀⢁⠀⠄⢀⠁⡀⠄⠀⠂⡀⢁⠈⢀⠀⠄⠁⡀⠄⠂⢀⠐\n" +
                "⠐⠈⡀⠁⡀⠐⠀⠠⠈⠀⠄⠁⡀⠂⢀⠐⠀⠐⠀⠄⠀⠄⠐⢀⠠⠐⠀⢁⠠⠀⠄⠂⠀⠄⠀⠄⠈⡀⠠⠀⠠⠀⠄⠐⠀⠠⠀⠂⠀⠄\n");

        System.out.println("블랙잭을 시작합니다.");
        System.out.println("딜러보다 최대한 21에 가깝게 맞쳐주세요.");
        System.out.println("카드는 1부터 10까지의 숫자가 나옵니다.");

        while(run) {
            System.out.print("숫자를 뽑으시겠습니까?(y/n)\n->");
            menu = sc.next();
            switch (menu) {
                case "y" :
                case "Y" :
                    //user의 배열 길이 늘리기
                    temp = user;
                    user = new int[user.length+1];
                    for(int i=0; i<temp.length; i++) {
                        user[i] = temp[i];
                    }

                    user[user.length-1] = (int)((Math.random()*10)+1);
                    System.out.println("========================");
                    System.out.println("유저가 " + user[user.length-1] + "를 뽑았습니다.");
                    for(int i=0; i<user.length; i++) {
                        userSum += user[i];
                    }
                    System.out.println("유저의 숫자의 총합 : " + userSum);
                    if(userSum == 21) {
                        System.out.println("유저가 승리했습니다.");
                        run = false;
                        result = true;
                    } else if(userSum > 21) {
                        System.out.println("유저가 패배했습니다.");
                        run = false;
                    }
                    userSum = 0;
                    System.out.println("========================");
                    break;
                case "n" :
                case "N" :
                    for(int i=0; i<dealer.length; i++) {
                        dealerSum += dealer[i];
                    }
                    for(int i=0; i<user.length; i++) {
                        userSum += user[i];
                    }
                    if(dealerSum>userSum) {
                        System.out.println("딜러가 승리했습니다.");
                    } else if (dealerSum<userSum) {
                        System.out.println("유저가 승리했습니다.");
                        result = true;
                    }
                    run = false;
                    break;
                default :
                    System.out.println("y/n 중에 입력해주세요.");
            }

            if((menu.equals("y") || menu.equals("Y") || menu.equals("n") || menu.equals("N")) && run) {
                dealer[dealer.length - 1] = (int) ((Math.random() * 10) + 1);
                System.out.println("========================");
                System.out.println("딜러가 " + dealer[dealer.length - 1] + "를 뽑았습니다.");
                for (int i = 0; i < dealer.length; i++) {
                    dealerSum += dealer[i];
                }

                System.out.println("딜러의 숫자의 총합 : " + dealerSum);
                if (dealerSum == 21) {
                    System.out.println("유저가 패배했습니다.");
                    run = false;
                } else if (dealerSum > 21) {
                    System.out.println("유저가 승리했습니다.");
                    result = true;
                    run = false;
                }
                dealerSum = 0;
                System.out.println("========================");
            }

            //dealer의 배열 길이 늘리기
            temp = dealer;
            dealer = new int[dealer.length+1];
            for(int i=0; i<temp.length; i++) {
                dealer[i] = temp[i];
            }
        }

        return result;
    }
}