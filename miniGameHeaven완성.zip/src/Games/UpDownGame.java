package Games;

import java.util.Scanner;

public class UpDownGame {
    //생성자
    public UpDownGame() { }

    //메소드

    //게임 시작 메소드
    public boolean startGame() {
        Scanner sc = new Scanner(System.in);
        boolean result = false;
        int randomNumber = (int)((Math.random()*100)+1);
        int number = 0;

        System.out.println("UP-DOWN 게임을 시작하겠습니다.");
        System.out.println("10번 내에 맞추셔야 합니다.");
        System.out.println("1~100 사이의 숫자를 입력해주세요.");
        for(int i=0; i<10; i++) {
            while(true) {
                System.out.print((i+1) + "번째 : ");
                number = sc.nextInt();
                if(number>100 || number<1) {
                    System.out.println("100 이하의 숫자를 입력해주세요.");
                } else {
                    break;
                }
            }

            if(number > randomNumber) {
                System.out.println("Down");
            } else if(number < randomNumber) {
                System.out.println("Up");
            } else {
                System.out.println("정답입니다!");
                result = true;
                break;
            }
        }
        if(number != randomNumber) {
            System.out.println("패배하셨습니다.");
        }
        return result;
    }
}
