package Games;

import java.util.Scanner;

public class RSPGame {
    public boolean startGame() {
        boolean result = false;

        boolean run = true;
        int random;
        String menu = null;
        String[] opponent = {"가위", "바위", "보"};
        Scanner sc = new Scanner(System.in);

        System.out.println("가위바위보를 시작하겠습니다.");

        while(run) {
            System.out.println("가위, 바위, 보를 입력해 주십시오.");
            menu = sc.next();

            random = (int)((Math.random()*3));
            System.out.println("상대 : " + opponent[random]);
            switch (menu) {
                case "가위" :
                    switch (random) {
                        case 0 :
                            System.out.println("비기셨습니다.");
                            break;
                        case 1 :
                            run = false;
                            System.out.println("졌습니다.");
                            break;
                        case 2 :
                            run = false;
                            result = true;
                            System.out.println("이겼습니다.");
                    }
                    break;
                case "바위" :
                    switch (random) {
                        case 0 :
                            run = false;
                            result = true;
                            System.out.println("이겼습니다.");
                            break;
                        case 1 :
                            System.out.println("비기셨습니다. 다시 입력해주세요.");
                            break;
                        case 2 :
                            run = false;
                            System.out.println("졌습니다.");
                    }
                    break;
                case "보" :
                    switch (random) {
                        case 0 :
                            run = false;
                            System.out.println("졌습니다.");
                            break;
                        case 1 :
                            run = false;
                            result = true;
                            System.out.println("이겼습니다.");
                            break;
                        case 2 :
                            System.out.println("비기셨습니다. 다시 입력해주세요.");
                    }
                    break;
                default:
                    System.out.println("잘못 입력하셨습니다.");
            }
        }

        return result;
    }
}